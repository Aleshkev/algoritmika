#include <iostream>
#include "twilib.h"
using namespace std;

typedef int I;

int main() {
	I n;// = inicjuj();
	cin >> n;

	I b = 0, e = n;

	I significant = 0;
	I c = 1;
	while(c < n) {
        c <<= 1;
        ++significant;
	}

	cout << c << " " << significant << " " << (1 << significant) << endl;

	bool *t = new bool[n];
	fill(t, t + n, true);

	while(significant < (1 << 5)) {
        I zeros = 0, ones = 0;
        for(I i = 1; i < n; ++i) {
            if(t[i]) {
                if(pytaj(i, significant)) {
                    ++ones;
                } else {
                    ++zeros;
                }
            }
        }



	}

	//odpowiedz(wyn);

	return 0;
}
