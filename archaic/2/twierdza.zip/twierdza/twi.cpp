#include <iostream>
#include "twilib.h"
#define init inicjuj
#define query pytaj
#define answer odpowiedz

using namespace std;

typedef int I;


void prtbin(I n) {
    cout << "0b";
    for(I i = 8; i >= 0; --i) {
        cout << bool(n & (1 << i));
    }
}


int main() {
	I n = init();
	I m = n - 1;

	I c = 1, d = 0;
	while(c <= n) c <<= 1, ++d;

	I missing = 0;
	I cleaner = 0;

	for(I i = 0; i < d; ++i) {

        I current, last = 1;
        I found = -1;
        for(I j = 0; j < n; ++j) {
            if((j & cleaner) == missing) {
                if(j == 0) {
                    current = 0;
                } else {
                    current = query(j, i);
                }
                if(current == last) {
                    found = !current;
                    break;
                }
                last = current;
            }
        }
        if(found == -1) {
            found = !current;
        }

        missing += (found << i);

        cleaner <<= 1;
        cleaner += 1;
	}

	answer(missing);

	return 0;
}
