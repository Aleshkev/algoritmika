#ifndef TWILIB_H
#define TWILIB_H

int inicjuj();

int pytaj(int k, int i);

void odpowiedz(int wynik);

#endif // TWILIB_H