from itertools import *
from random import *
from string import *


def get_hash(s):
    v = 0
    for c in s:
        v = (((v << 5) | (v >> 27)) ^ ord(c)) % (1 << 32)
    return v


# for i in range(10**100):
#     s = [choice(ascii_lowercase) for _ in range(10)]
#     v = get_hash(s)
#     if v < 3 * 10**4:
#         print("".join(s), v)


def next_product(s):
    i = len(s) - 1
    s[i] = chr(ord(s[i]) + 1)
    while ord(s[i]) > ord('z'):
        s[i] = 'a'
        i = i - 1
        s[i] = chr(ord(s[i]) + 1)
    return s


d = {}


def check_next(s):
    for i in range(1000):
        v = get_hash(s)
        if v in d.keys():
            print("".join(s), d[v], v)
            return
        d[v] = "".join(s)
        s = next_product(s)


check_next(list("nvyoccxnsr"))
check_next(list("jxpoccymcf"))
