from zipfile import *
from pathlib import *

with ZipFile("submit.zip", "w") as f:
    v = list(filter((lambda x: x and not x.startswith("#")), Path(
        "found.txt").read_text("utf-8").splitlines()))
    for i, (a, b) in enumerate(zip(v[::2], v[1::2]), 1):
        f.writestr(f"{i}.txt", a + "\n" + b + "\n")
