"""Anti-rolling-hash test generation by lattice reduction
original code by Hellman_, modified by dacin21
"""

from sage.all import *


def anti_hash(PAs, string_length, sigma, block_size, MULTIPLIER=100000, sigma_base=ord('a')):
    n = len(PAs)
    N = string_length
    As = [a for p, a in PAs]
    Ps = [p for p, a in PAs]

    def h(s):
        """polynomial hash modulo <n> primes"""
        v = [0] * n
        for c in s:
            v = [(x * q + ord(c)) % p for x, q, p in zip(v, As, Ps)]
        return tuple(v % p for v, p in zip(v, Ps))

    mv = matrix(ZZ, N, N)
    for y in xrange(N):
        for x, q, p in zip(range(n), As, Ps):
            mv[y, x] = pow(q, N-y-1, p)

    m = matrix(ZZ, N + n, N + n)
    # submatrix with terms
    m.set_block(0, 0, MULTIPLIER * mv)
    # modulo reductions
    m.set_block(N, 0, MULTIPLIER * diagonal_matrix(Ps))
    # term coefficients
    m.set_block(0, n, identity_matrix(N))
    # 4th submatrix is zero

    m_reduced = m.LLL()
    if block_size > 0:
        m_reduced = m_reduced.BKZ(block_size=block_size)

    for row in m_reduced:
        print row[:n], min(row[n:]), "~", max(row[n:])
        delta = max(abs(v) for v in row[n:])
        if set(row[:n]) == {0} and delta < sigma:
            print "Found collision!"
            s = [None] * N
            t = [None] * N
            for i, v in enumerate(row[n:]):
                a = sigma_base
                b = a + abs(v)
                if v > 0:
                    a, b = b, a
                s[i] = a
                t[i] = b
            s = "".join(map(chr, s))
            t = "".join(map(chr, t))
            print s + " " + t
            # print h(s)
            # print h(t)
            assert h(s) == h(t)
            break
    else:
        print "Failed to find collision, try a larger string_length"
        print "For lengths > 30, setting block_size to 10 or 15 is recommended"


if __name__ == '__main__':
    PAs = [[2009393647044798450, 195688749456722940],
           [14772471554262078307, 10171877582990714540],
           [3868942717470439770, 12881977372630504442],
           [10116414958431080609, 14992807499564125639],
           [12240684982096309196, 8533976720013886615],
           [13927438274629806502, 18146351945582388344],
           [15394825880068674429, 8852360169711692322],
           [17900932972021141111, 6046410735046753737],
           [2389526654270988215, 101593162357938336],
           [7983949436602086553, 17366427465974227976],
           [6812212898381342636, 14473938324428218966],
           [17185183462413892013, 9448466573266392919],
           [11992997003736263135, 15873389189717648135],
           [4322996945210141216, 5815835263440967534],
           [13937631880559704775, 12080672730796021322],
           [14593148736838752946, 452672781690685990], ]
    # for i in range(len(PAs)):
    #    PAs[i] = [max(PAs[i][0], PAs[i][1]), min(PAs[i][0], PAs[i][1])]
    # with open("hash.in", 'r') as infile:
    #    n, k, sigma = map(int, infile.readline().strip().split())
    #    PAs = [tuple(map(int, infile.readline().strip().split())) for _ in xrange(n)]
    #    anti_hash(PAs, k, sigma)
    anti_hash(PAs, 400, 26, 10)
