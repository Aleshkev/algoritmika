#include <bits/stdc++.h>
using namespace std;

unsigned hash1(std::string const& S) {
  unsigned val = 0;
  for (char c : S) {
    val = ((val << 5) | (val >> 27)) ^ c;
  }
  return val;
}
bool f1(std::string const& A, std::string const& B) {
  if (A.length() != B.length()) return false;
  return hash1(A) == hash1(B);
}

unsigned long long hash2(std::string const& S) {
  unsigned long long val = 0;
  const long long P = 125097457;
  const long long Q = 989249411;
  for (char c : S) {
    val = (val * P + c) % Q;
  }
  return val;
}
bool f2(std::string const& A, std::string const& B) {
  if (A.length() != B.length()) return false;
  return hash2(A) == hash2(B);
}

unsigned long long hash3(std::string const& s) {
  unsigned long long val = 0;
  const long long p = 1235031313;
  for (char c : s) {
    val = val * p + c;
  }
  return val;
}
bool f3(std::string const& a, std::string const& b) {
  if (a.length() != b.length()) return false;
  return hash3(a) == hash3(b);
}

unsigned long long hash4(std::string const& S) {
  unsigned long long val = 0;
  const long long P = 123456789129921817ll;
  const long long Q = 987654321990767903ll;
  for (char c : S) {
    val = (static_cast<__uint128_t>(val) * P + c) % Q;
  }
  return val;
}
bool f4(std::string const& A, std::string const& B) {
  if (A.length() != B.length()) return false;
  return hash4(A) == hash4(B);
}

std::vector<long long unsigned>
    Ps = {195688749456722940llu,   10171877582990714540llu,
          12881977372630504442llu, 14992807499564125639llu,
          8533976720013886615llu,  18146351945582388344llu,
          8852360169711692322llu,  6046410735046753737llu,
          101593162357938336llu,   17366427465974227976llu,
          14473938324428218966llu, 9448466573266392919llu,
          15873389189717648135llu, 5815835263440967534llu,
          12080672730796021322llu, 452672781690685990llu},
    Qs = {2009393647044798450llu,  14772471554262078307llu,
          3868942717470439770llu,  10116414958431080609llu,
          12240684982096309196llu, 13927438274629806502llu,
          15394825880068674429llu, 17900932972021141111llu,
          2389526654270988215llu,  7983949436602086553llu,
          6812212898381342636llu,  17185183462413892013llu,
          11992997003736263135llu, 4322996945210141216llu,
          13937631880559704775llu, 14593148736838752946llu};
unsigned long long hash5(std::string const& S, long long unsigned P,
                         long long unsigned Q) {
  unsigned long long val = 0;
  for (char c : S) {
    val = (static_cast<__uint128_t>(val) * P + c) % Q;
  }
  return val;
}
bool f5(std::string const& A, std::string const& B) {
  if (A.length() != B.length()) return false;
  for (int i = 0; i < 16; i++) {
    if (hash5(A, Ps[i], Qs[i]) != hash5(B, Ps[i], Qs[i])) {
      return false;
    }
  }
  return true;
}

int main() {
  cout << "1: " << f1("jxpoccymda", "nvyoccxnvi") << endl;
  cout << "2: " << f2("aabaaaaaaaaaaaaaaaaa", "bbababbabbaaaabaaaab") << endl;
  cout << "3: " << f3("aceaaeaaacaabbaeacba", "aaaecacbaaceaaaaaaag") << endl;
  cout << "4: "
       << f4("aabbaabbbaaaaaabbabaaaaaaabaaaabaabaaaaaabaaaaabaa",
             "aaaaaaaaaaaaaaaaaaaaaababaaaaaaaabababaaaaaaaababa")
       << endl;

#ifdef UNITEST
  system("pause");
#endif
}
