import pathlib

import selenium
import selenium.webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select


def template(n):
    return """
// """ + str(n) + """
bool pierwszy_raz = true;
int ile_wiezniow = 0;
int izolatka(int nr_wieznia, int nr_dnia, bool zarowka) {
  if (nr_wieznia == """ + str(n) + """) {
    if (zarowka) ile_wiezniow++;
    if (ile_wiezniow == 99) return 2;
    return 0;
  }
  if (!zarowka && pierwszy_raz) {
    pierwszy_raz = false;
    return 1;
  }
  return zarowka;
}
"""


login_url = "https://sio2.staszic.waw.pl/c/warsztaty-finalowe-2019/login/"
submit_url = "https://sio2.staszic.waw.pl/c/wwi-2019-off/submit/"

driver = selenium.webdriver.Chrome()
driver.get(login_url)

driver.find_element_by_id("id_username").send_keys("u65848")
driver.find_element_by_id("id_password").send_keys(pathlib.Path("password.txt").read_text())
driver.find_element_by_id("id_submit").click()

for i in range(1, 50):
    driver.get(submit_url)
    Select(driver.find_element_by_id("id_problem_instance_id")).select_by_visible_text("Więźniowie (wiezniowie)")
    driver.find_element_by_id("id_code").send_keys(template(i))
    Select(driver.find_element_by_id("id_prog_lang")).select_by_visible_text("C++")
    driver.find_element_by_tag_name("button").click()
