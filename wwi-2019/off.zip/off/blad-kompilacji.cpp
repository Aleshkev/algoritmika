#define a(x) \
  x "0 " x "1 " x "2 " x "3 " x "4 " x "5 " x "6 " x "7 " x "8 " x "9 "
#define b(x)                                                              \
  a(x "0") a(x "1") a(x "2") a(x "3") a(x "4") a(x "5") a(x "6") a(x "7") \
      a(x "8") a(x "9")
#define c(x)                                                              \
  b(x "0") b(x "1") b(x "2") b(x "3") b(x "4") b(x "5") b(x "6") b(x "7") \
      b(x "8") b(x "9")
#define d(x)                                                              \
  c(x "0") c(x "1") c(x "2") c(x "3") c(x "4") c(x "5") c(x "6") c(x "7") \
      c(x "8") c(x "9")
#define e(x)                                                              \
  d(x "0") d(x "1") d(x "2") d(x "3") d(x "4") d(x "5") d(x "6") d(x "7") \
      d(x "8") d(x "9")
#define f(x) e(x "0")  // e(x "1")  // e(x "2") e(x "3")

#pragma message a("") b("") c("") d("") e("") f("")
