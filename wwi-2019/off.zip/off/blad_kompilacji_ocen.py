from pathlib import *
from re import *

P = Path

s = P("t3.txt").read_text()
print(len(s), "/", 100 * 1024 + 1)
s = s[:100 * 1024]

t = findall("[0-9]+", s)
print(" ".join(t[:10]), "...", " ".join(t[-10:]))

t = set(t)

print(len(t))
