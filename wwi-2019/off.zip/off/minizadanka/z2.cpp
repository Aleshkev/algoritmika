#include <cstdio>
void fun() {
  auto sekret = 42;
  puts("ACHTUNG!");
  printf("%llu\n", sekret);
  puts("ENDE!");
}
