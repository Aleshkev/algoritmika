from subprocess import *
from pathlib import *
from collections import *

path = Path("choinka.c")


p = run(
    ["python", 'C:/Users/Franz/OneDrive/Documents/Python Projects/epp/main.py', f"{path}"], capture_output=True)
s = p.stdout.decode("utf-8").strip()
print(s)

c = sorted(list(Counter(s).items()), key=lambda x: x[1], reverse=True)

for k, v in c:
    print(repr(k), v)
print(len(c), "chars")

print(sorted([x[0] for x in c]))
