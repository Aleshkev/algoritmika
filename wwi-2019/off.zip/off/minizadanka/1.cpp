struct S {
  int v;
  S(int v) : v(v) {}

  bool operator!=(int o) { return false; }
  bool operator==(int o) { return true; }
};

#define fun(X) xfun(S x)
#include "z1.h"

int main() { xfun(S(0)); }
