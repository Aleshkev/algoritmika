from pathlib import *
from zipfile import *
import sys

p = Path(".")

n = int(sys.argv[1]) - 1 if len(sys.argv) > 1 else None

c = 0
with ZipFile("pack.zip", "w", ZIP_DEFLATED) as zipf:
    for i, f in enumerate(list(p.glob("?.cpp")) + list(p.glob("?.py"))):
        if n is not None and i > n:
            break
        print(f, repr(f.read_text()[:64]))
        zipf.write(f)
