#include "z2.h"
extern "C" int puts(const char *s) { return 0; };

int main() { fun(); }
