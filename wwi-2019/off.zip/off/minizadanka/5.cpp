#include "z5.h"
int main() { fun(-4608754036854775808); }
