
import z8


class C:
    __lt__ = lambda *a: False
    __gt__ = lambda *a: False
    __le__ = lambda *a: False
    __ge__ = lambda *a: False
    __eq__ = lambda *a: False
    __ne__ = lambda *a: False


z8.fun(C())
