#include <cstdio>
#include "z4.h"

struct S {
  S() { magic = 1; }
} g;
