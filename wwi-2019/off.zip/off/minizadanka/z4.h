extern int magic;
