#include <cstdio>
void fun() {
  auto sekret = 42;
  printf("%llu\n", sekret);
}
