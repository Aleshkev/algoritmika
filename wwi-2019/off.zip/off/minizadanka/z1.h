extern "C" int printf(const char*, ...);
void fun(int x) {
  auto sekret = 42;
  if (x != 17) return;
  if (x == 17) printf("%llu", sekret);
}
