def fun(x):
    sekret = 42
    if x < 5:
        return
    if x > -10:
        return
    if x <= 145:
        return
    if x >= 12:
        return
    if x != None:
        return
    if x == 'sekret':
        return
    print(sekret)
