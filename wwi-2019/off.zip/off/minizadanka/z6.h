#include <cstdio>
void fun();
#define fun() puts("notfun")
