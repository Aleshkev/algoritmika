#include "z3.h"
extern "C" int sprintf(char* s, const char* z, ...) {
  s[0] = '0';
  return 0;
};
extern "C" int puts(const char* s) { return 0; };

#define x (a)

int main() {
  fun();
  x(7);
}
