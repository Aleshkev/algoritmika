void fun();

int main() { fun(); }
