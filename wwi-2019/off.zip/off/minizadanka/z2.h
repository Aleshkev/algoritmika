void fun();
