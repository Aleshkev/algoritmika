#include <cstdio>
void fun() {
  auto sekret = 42;

  char buffer[20];
  puts("hello");
  sprintf(buffer, "%d");
  printf("%s", buffer);

  if (*(short*)buffer == '0') {
    printf("%llu\n", sekret);
  }
}
