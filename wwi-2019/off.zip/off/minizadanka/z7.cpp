long long unsigned uknown_name() {
  auto sekret = 42;
  return sekret;
}
