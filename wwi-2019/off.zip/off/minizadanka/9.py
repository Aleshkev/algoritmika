import z9
import re
import dis

print(list(dis.get_instructions(z9.fun))[0].argval)
