#include <cstdio>
int magic = 0;
int main() {
  auto sekret = 42;
  if (magic == 1) printf("%llu\n", sekret);
}
