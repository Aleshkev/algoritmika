def fun():
    sekret = 42
