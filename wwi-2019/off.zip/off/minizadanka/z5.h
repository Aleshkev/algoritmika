void fun(long long);
